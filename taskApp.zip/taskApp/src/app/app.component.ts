import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
    title = 'taskApp';
    numberArray: any = [];

    ngOnInit() {

    }

    fileUpload(event) {
        let reader = new FileReader();
        reader.readAsText(event.srcElement.files[0]);
        reader.onload = () => {
            this.compareAndCreateCharacter(reader.result);
        }
    }

    compareAndCreateCharacter(dataStream) {
        let arrayStream = dataStream.split('\n');
        if (arrayStream.length > 0) {
            console.log(Date.now());
            for (let i = 0; i < arrayStream.length; i = i + 4) {
                if (arrayStream[i].length == 27) {
                    let numb = "";
                    for (let j = 0; j < arrayStream[i].length; j = j + 3) {
                        if ((arrayStream[i][j] + arrayStream[i][j + 1] + arrayStream[i][j + 2]).toString().trim() == '' && (arrayStream[i + 1][j] + arrayStream[i + 1][j + 1] + arrayStream[i + 1][j + 2]).toString().trim() == '|' && (arrayStream[i + 2][j] + arrayStream[i + 2][j + 1] + arrayStream[i + 2][j + 2]).toString().trim() == '|') {
                            // character possibilty 1
                            numb = numb + 1;


                        } else if (arrayStream[i][j] + arrayStream[i][j + 1] + arrayStream[i][j + 2] == ' _ ' && arrayStream[i + 1][j] + arrayStream[i + 1][j + 1] + arrayStream[i + 1][j + 2] == ' _|' && arrayStream[i + 2][j] + arrayStream[i + 2][j + 1] + arrayStream[i + 2][j + 2] == '|_ ') {
                            // character possibilty 2
                            numb = numb + 2;

                        } else if (arrayStream[i][j] + arrayStream[i][j + 1] + arrayStream[i][j + 2] == ' _ ' && arrayStream[i + 1][j] + arrayStream[i + 1][j + 1] + arrayStream[i + 1][j + 2] == ' _|' && arrayStream[i + 2][j] + arrayStream[i + 2][j + 1] + arrayStream[i + 2][j + 2] == ' _|') {
                            // character is 3
                            numb = numb + 3;

                        } else if (arrayStream[i][j] + arrayStream[i][j + 1] + arrayStream[i][j + 2] == '   ' && arrayStream[i + 1][j] + arrayStream[i + 1][j + 1] + arrayStream[i + 1][j + 2] == '|_|' && arrayStream[i + 2][j] + arrayStream[i + 2][j + 1] + arrayStream[i + 2][j + 2] == '  |') {
                            // character is 4
                            numb = numb + 4;

                        } else if (arrayStream[i][j] + arrayStream[i][j + 1] + arrayStream[i][j + 2] == ' _ ' && arrayStream[i + 1][j] + arrayStream[i + 1][j + 1] + arrayStream[i + 1][j + 2] == '|_ ' && arrayStream[i + 2][j] + arrayStream[i + 2][j + 1] + arrayStream[i + 2][j + 2] == ' _|') {
                            // character is 5
                            numb = numb + 5;

                        } else if (arrayStream[i][j] + arrayStream[i][j + 1] + arrayStream[i][j + 2] == ' _ ' && arrayStream[i + 1][j] + arrayStream[i + 1][j + 1] + arrayStream[i + 1][j + 2] == '|_ ' && arrayStream[i + 2][j] + arrayStream[i + 2][j + 1] + arrayStream[i + 2][j + 2] == '|_|') {
                            // character is 6
                            numb = numb + 6;

                        } else if (arrayStream[i][j] + arrayStream[i][j + 1] + arrayStream[i][j + 2] == ' _ ' && arrayStream[i + 1][j] + arrayStream[i + 1][j + 1] + arrayStream[i + 1][j + 2] == '  |' && arrayStream[i + 2][j] + arrayStream[i + 2][j + 1] + arrayStream[i + 2][j + 2] == '  |') {
                            // character is 7
                            numb = numb + 7;

                        } else if (arrayStream[i][j] + arrayStream[i][j + 1] + arrayStream[i][j + 2] == ' _ ' && arrayStream[i + 1][j] + arrayStream[i + 1][j + 1] + arrayStream[i + 1][j + 2] == '|_|' && arrayStream[i + 2][j] + arrayStream[i + 2][j + 1] + arrayStream[i + 2][j + 2] == '|_|') {
                            // character is 8
                            numb = numb + 8;

                        } else if (arrayStream[i][j] + arrayStream[i][j + 1] + arrayStream[i][j + 2] == ' _ ' && arrayStream[i + 1][j] + arrayStream[i + 1][j + 1] + arrayStream[i + 1][j + 2] == '|_|' && arrayStream[i + 2][j] + arrayStream[i + 2][j + 1] + arrayStream[i + 2][j + 2] == ' _|') {
                            // character is 9
                            numb = numb + 9;

                        }
                        else if (arrayStream[i][j] + arrayStream[i][j + 1] + arrayStream[i][j + 2] == ' _ ' && arrayStream[i + 1][j] + arrayStream[i + 1][j + 1] + arrayStream[i + 1][j + 2] == '| |' && arrayStream[i + 2][j] + arrayStream[i + 2][j + 1] + arrayStream[i + 2][j + 2] == '|_|') {
                            // character is 9
                            numb = numb + 0;

                        }
                        else {
                            numb = numb + '?';
                        }
                    }

                    if (numb.includes('?')) {
                        numb = numb + "Illegal Statement";
                    }
                    this.numberArray.push(numb);

                } else {
                    // this.numberArray.push('');
                }
            }
            console.log(Date.now());
        }
        console.log(this.numberArray);
        console.log(Date.now());
        // this.createFile(this.numberArray);
    }

}
